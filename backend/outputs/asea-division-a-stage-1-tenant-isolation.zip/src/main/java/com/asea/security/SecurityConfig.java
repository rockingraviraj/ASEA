package com.asea.security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.HttpStatusEntryPoint;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

/**
 * Spring Security configuration for the ASEA Control Plane.
 *
 * <p><b>MVP authentication strategy:</b> API-key header authentication.
 * The caller must supply {@code X-ASEA-API-Key: <configured-value>} on every request
 * to the protected {@code /api/**} namespace.</p>
 *
 * <p>Public endpoints (Swagger UI, actuator health probes) are permitted without
 * a key to support operational tooling.</p>
 *
 * <p><b>Security gap acknowledged:</b> This is a single shared API-key model.
 * It does not establish per-tenant identity — the tenantId in request bodies
 * is still caller-supplied. A proper JWT / OAuth2 OIDC integration (which would
 * bind the tenant from the authenticated principal) is the required next step
 * before production use. This gap is documented in the Stage 1 report.</p>
 *
 * <p>Never log or return the API key value in any response or log output.</p>
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig {

    private static final Logger log = LoggerFactory.getLogger(SecurityConfig.class);

    private final ApiKeyAuthenticationFilter apiKeyFilter;

    public SecurityConfig(ApiKeyAuthenticationFilter apiKeyFilter) {
        this.apiKeyFilter = apiKeyFilter;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            // Disable CSRF — this is a stateless REST API with no browser sessions
            .csrf(AbstractHttpConfigurer::disable)

            // Stateless session — no HTTP sessions created or used
            .sessionManagement(sm -> sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))

            // Return 401 (not 302 redirect) for unauthenticated API access
            .exceptionHandling(eh -> eh
                .authenticationEntryPoint(new HttpStatusEntryPoint(HttpStatus.UNAUTHORIZED)))

            // Endpoint authorization rules
            .authorizeHttpRequests(auth -> auth
                // Public: Swagger UI and OpenAPI spec
                .requestMatchers(
                    "/swagger-ui/**",
                    "/swagger-ui.html",
                    "/v3/api-docs/**",
                    "/v3/api-docs"
                ).permitAll()
                // Public: Actuator health and readiness probes (used by container orchestrators)
                .requestMatchers(
                    "/actuator/health",
                    "/actuator/health/**",
                    "/actuator/info"
                ).permitAll()
                // Everything else requires a valid API key
                .anyRequest().authenticated()
            )

            // Insert the API-key filter before the standard username/password filter
            .addFilterBefore(apiKeyFilter, UsernamePasswordAuthenticationFilter.class);

        log.info("ASEA SecurityFilterChain configured: API-key authentication, stateless sessions");
        return http.build();
    }
}
