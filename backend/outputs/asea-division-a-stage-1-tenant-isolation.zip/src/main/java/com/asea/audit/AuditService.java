package com.asea.audit;

import com.asea.security.TenantResolver;
import com.asea.state.TaskState;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Central audit recording service.
 *
 * <p>Runs in {@link Propagation#REQUIRES_NEW} so that an audit record is
 * always committed even if the outer transaction rolls back. This ensures
 * audit completeness including failure events.</p>
 *
 * <p><b>Tenant Isolation:</b> Audit reads are strictly tenant-scoped.
 * Public/service-facing read methods derive tenant identity server-side from
 * {@link TenantResolver}. Callers cannot read audit logs across tenant boundaries.</p>
 */
@Service
public class AuditService {

    private static final Logger log = LoggerFactory.getLogger(AuditService.class);

    private final AuditLogRepository auditLogRepository;
    private final TenantResolver tenantResolver;

    public AuditService(AuditLogRepository auditLogRepository, TenantResolver tenantResolver) {
        this.auditLogRepository = auditLogRepository;
        this.tenantResolver = tenantResolver;
    }

    /**
     * Records an audit event. Runs in its own transaction to guarantee persistence.
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public AuditLog record(String tenantId,
                           AuditEventType eventType,
                           String actor,
                           String taskId,
                           TaskState previousState,
                           TaskState newState,
                           String metadata) {
        AuditLog auditLog = new AuditLog();
        auditLog.setTenantId(tenantId);
        auditLog.setEventType(eventType);
        auditLog.setActor(actor != null ? actor : "SYSTEM");
        auditLog.setTaskId(taskId);
        auditLog.setPreviousState(previousState);
        auditLog.setNewState(newState);
        auditLog.setMetadata(metadata);
        auditLog.setCreatedAt(LocalDateTime.now());

        AuditLog saved = auditLogRepository.save(auditLog);
        log.debug("Audit recorded eventType={} taskId={} actor={} tenantId={}",
                eventType, taskId, actor, tenantId);
        return saved;
    }

    /**
     * Convenience overload for events not associated with a specific task.
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public AuditLog record(String tenantId, AuditEventType eventType, String actor, String metadata) {
        return record(tenantId, eventType, actor, null, null, null, metadata);
    }

    /**
     * Retrieves audit logs for a task scoped strictly to the authenticated tenant.
     * Prevents cross-tenant access to audit entries.
     *
     * @param taskId the task ID
     * @return audit logs for the task belonging to the authenticated tenant
     */
    @Transactional(readOnly = true)
    public List<AuditLog> getAuditLogsForTask(String taskId) {
        String tenantId = tenantResolver.resolveRequiredTenantId();
        return auditLogRepository.findByTenantIdAndTaskIdOrderByCreatedAtAsc(tenantId, taskId);
    }

    /**
     * Retrieves audit logs for a task validating an optional tenant assertion.
     *
     * @param taskId the task ID
     * @param assertedTenantId optional caller assertion (must match authenticated tenant if supplied)
     * @return audit logs for the task belonging to the authenticated tenant
     */
    @Transactional(readOnly = true)
    public List<AuditLog> getAuditLogsForTask(String taskId, String assertedTenantId) {
        String tenantId = tenantResolver.validateAndResolveTenant(assertedTenantId);
        return auditLogRepository.findByTenantIdAndTaskIdOrderByCreatedAtAsc(tenantId, taskId);
    }

    /**
     * Internal infrastructure use only — caller must supply a verified tenant ID derived from
     * trusted persisted task data (e.g. background worker or reconciler).
     */
    @Transactional(readOnly = true)
    public List<AuditLog> getAuditLogsForTaskInternal(String tenantId, String taskId) {
        if (!StringUtils.hasText(tenantId)) {
            throw new IllegalArgumentException("tenantId must not be blank for internal audit lookup");
        }
        return auditLogRepository.findByTenantIdAndTaskIdOrderByCreatedAtAsc(tenantId, taskId);
    }
}
