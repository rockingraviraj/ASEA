package com.asea.budget;

import com.asea.audit.AuditEventType;
import com.asea.audit.AuditService;
import com.asea.common.exceptions.BudgetExceededException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Budget Manager — enforces spending limits for tasks.
 *
 * <p>Before any expensive operation (LLM call, sandbox execution), the orchestrator
 * checks the budget. When a limit is exceeded, the task is escalated rather than
 * allowed to continue indefinitely.</p>
 *
 * <p>Uses pessimistic locking to prevent race conditions when multiple concurrent
 * operations consume budget simultaneously.</p>
 *
 * <p><b>Fail-closed contract:</b> if no budget record is found for a task, execution
 * is DENIED (not allowed). Every task must have an initialised budget; absence of a
 * budget record is treated as a configuration error, not a permission to proceed.</p>
 *
 * <p>No infinite loops: when budget is exhausted, execution stops and the task
 * transitions to ESCALATED.</p>
 *
 * <p><b>Tenant isolation:</b> all budget read and write operations use tenant-scoped
 * repository queries (tenantId + taskId). The tenantId is obtained from the persisted
 * task record or the authenticated principal — never from untrusted caller input.</p>
 */
@Service
public class BudgetManager {

    private static final Logger log = LoggerFactory.getLogger(BudgetManager.class);

    private final BudgetRepository budgetRepository;
    private final AuditService auditService;
    private final ObjectMapper objectMapper;

    public BudgetManager(BudgetRepository budgetRepository,
                         AuditService auditService,
                         ObjectMapper objectMapper) {
        this.budgetRepository = budgetRepository;
        this.auditService = auditService;
        this.objectMapper = objectMapper;
    }

    /**
     * Initialises a budget record when a task is created.
     * Called within the same transaction as task creation — failure is atomic.
     */
    @Transactional
    public Budget initializeBudget(String tenantId, String taskId,
                                   Long maxTokens, BigDecimal maxCost,
                                   Integer maxAttempts, Long maxExecutionMs) {
        Budget budget = new Budget();
        budget.setTenantId(tenantId);
        budget.setTaskId(taskId);
        budget.setMaxTokens(maxTokens);
        budget.setMaxCost(maxCost);
        budget.setMaxAttempts(maxAttempts != null ? maxAttempts : 3);
        budget.setMaxExecutionMs(maxExecutionMs);
        budget.setUsedTokens(0L);
        budget.setUsedCost(BigDecimal.ZERO);
        budget.setCurrentAttempts(0);
        budget.setStartedAt(LocalDateTime.now());
        budget.setStatus("ACTIVE");
        budget.setCreatedAt(LocalDateTime.now());
        budget.setUpdatedAt(LocalDateTime.now());

        Budget saved = budgetRepository.save(budget);
        log.info("Budget initialized taskId={} tenantId={} maxTokens={} maxCost={} maxAttempts={}",
                taskId, tenantId, maxTokens, maxCost, maxAttempts);
        return saved;
    }

    /**
     * Checks whether the task has sufficient budget to proceed.
     *
     * <p><b>Fail-closed:</b> if no budget record exists for the task, execution is DENIED.
     * The absence of a budget is a configuration error — tasks must have an initialised budget.</p>
     *
     * <p>Does NOT consume budget — call {@link #consume} after the operation completes.</p>
     *
     * @param tenantId the verified tenant ID from the persisted task record
     * @param taskId   the task's public identifier
     */
    @Transactional(readOnly = true)
    public BudgetCheckResult check(String tenantId, String taskId) {
        // Fail-closed: missing budget = DENY
        Budget budget = budgetRepository.findByTenantIdAndTaskId(tenantId, taskId).orElse(null);
        if (budget == null) {
            log.warn("Budget record missing — denying execution taskId={} tenantId={}", taskId, tenantId);
            return BudgetCheckResult.deny("No budget record found for task " + taskId +
                    ". Every task requires an initialised budget.");
        }

        if (budget.isTokenBudgetExhausted()) {
            log.warn("Budget token limit exhausted taskId={} used={} max={}",
                    taskId, budget.getUsedTokens(), budget.getMaxTokens());
            auditBudget(budget, "TOKEN_LIMIT_EXCEEDED");
            return BudgetCheckResult.deny("Token limit exceeded: used="
                    + budget.getUsedTokens() + " max=" + budget.getMaxTokens());
        }
        if (budget.isCostBudgetExhausted()) {
            log.warn("Budget cost limit exhausted taskId={} used={} max={}",
                    taskId, budget.getUsedCost(), budget.getMaxCost());
            auditBudget(budget, "COST_LIMIT_EXCEEDED");
            return BudgetCheckResult.deny("Cost limit exceeded: used="
                    + budget.getUsedCost() + " max=" + budget.getMaxCost());
        }
        if (budget.isAttemptBudgetExhausted()) {
            log.warn("Budget attempt limit exhausted taskId={} used={} max={}",
                    taskId, budget.getCurrentAttempts(), budget.getMaxAttempts());
            auditBudget(budget, "ATTEMPT_LIMIT_EXCEEDED");
            return BudgetCheckResult.deny("Attempt limit exceeded: used="
                    + budget.getCurrentAttempts() + " max=" + budget.getMaxAttempts());
        }

        Integer remaining = budget.getMaxAttempts() != null
                ? budget.getMaxAttempts() - budget.getCurrentAttempts() : null;
        return BudgetCheckResult.allow(budget.remainingTokens(), null, remaining);
    }

    /**
     * Enforces budget — throws {@link BudgetExceededException} if exhausted or missing.
     *
     * @param tenantId the verified tenant ID from the persisted task record
     * @param taskId   the task's public identifier
     */
    public void enforce(String tenantId, String taskId) {
        BudgetCheckResult result = check(tenantId, taskId);
        if (!result.allowed()) {
            throw new BudgetExceededException("Budget exhausted for task " + taskId
                    + ": " + result.exhaustedReason());
        }
    }

    /**
     * Records consumption of tokens and cost after an LLM call.
     * Uses tenant-scoped pessimistic lock to prevent concurrent update corruption.
     *
     * @param tenantId    the verified tenant ID from the persisted task record
     * @param taskId      the task's public identifier
     * @param tokensUsed  tokens consumed (must be non-negative)
     * @param costIncurred cost incurred (must be non-negative)
     * @throws IllegalArgumentException if tokensUsed or costIncurred is negative
     */
    @Transactional
    public void consume(String tenantId, String taskId, long tokensUsed, BigDecimal costIncurred) {
        if (tokensUsed < 0) {
            throw new IllegalArgumentException("tokensUsed must not be negative, got: " + tokensUsed);
        }
        if (costIncurred != null && costIncurred.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("costIncurred must not be negative, got: " + costIncurred);
        }

        // Tenant-scoped pessimistic lock
        Budget budget = budgetRepository.findByTenantIdAndTaskIdForUpdate(tenantId, taskId).orElse(null);
        if (budget == null) {
            log.error("Cannot consume budget — record missing taskId={} tenantId={}", taskId, tenantId);
            throw new BudgetExceededException("No budget record found for task " + taskId);
        }

        budget.setUsedTokens((budget.getUsedTokens() != null ? budget.getUsedTokens() : 0L) + tokensUsed);
        BigDecimal current = budget.getUsedCost() != null ? budget.getUsedCost() : BigDecimal.ZERO;
        budget.setUsedCost(current.add(costIncurred != null ? costIncurred : BigDecimal.ZERO));
        budget.setUpdatedAt(LocalDateTime.now());
        budgetRepository.save(budget);

        log.debug("Budget consumed taskId={} tokens={} cost={} totalTokens={} totalCost={}",
                taskId, tokensUsed, costIncurred, budget.getUsedTokens(), budget.getUsedCost());
        auditBudget(budget, "CONSUMED");
    }

    /**
     * Increments the attempt counter. Call when starting a new attempt/retry.
     * Uses tenant-scoped pessimistic lock.
     *
     * @param tenantId the verified tenant ID from the persisted task record
     * @param taskId   the task's public identifier
     */
    @Transactional
    public void incrementAttempts(String tenantId, String taskId) {
        // Tenant-scoped pessimistic lock
        Budget budget = budgetRepository.findByTenantIdAndTaskIdForUpdate(tenantId, taskId).orElse(null);
        if (budget == null) {
            log.error("Cannot increment attempts — budget record missing taskId={} tenantId={}", taskId, tenantId);
            throw new BudgetExceededException("No budget record found for task " + taskId);
        }

        int newAttempts = (budget.getCurrentAttempts() != null ? budget.getCurrentAttempts() : 0) + 1;
        budget.setCurrentAttempts(newAttempts);
        budget.setUpdatedAt(LocalDateTime.now());
        budgetRepository.save(budget);

        log.info("Budget attempt incremented taskId={} currentAttempts={} maxAttempts={}",
                taskId, newAttempts, budget.getMaxAttempts());
    }

    // -------------------------------------------------------------------------
    // Internal helpers
    // -------------------------------------------------------------------------

    /**
     * Builds audit metadata using Jackson ObjectMapper to guarantee valid JSON.
     */
    private void auditBudget(Budget budget, String event) {
        String metadata;
        try {
            ObjectNode node = objectMapper.createObjectNode();
            node.put("event", event);
            node.put("usedTokens", budget.getUsedTokens() != null ? budget.getUsedTokens() : 0L);
            node.put("usedCost",
                    budget.getUsedCost() != null ? budget.getUsedCost().toPlainString() : "0");
            node.put("currentAttempts",
                    budget.getCurrentAttempts() != null ? budget.getCurrentAttempts() : 0);
            metadata = objectMapper.writeValueAsString(node);
        } catch (Exception e) {
            log.error("Failed to serialize budget audit metadata: {}", e.getMessage(), e);
            metadata = "{\"error\":\"serialization_failed\"}";
        }
        auditService.record(budget.getTenantId(), AuditEventType.BUDGET_CHECKED,
                "BUDGET_MANAGER", budget.getTaskId(), null, null, metadata);
    }
}
