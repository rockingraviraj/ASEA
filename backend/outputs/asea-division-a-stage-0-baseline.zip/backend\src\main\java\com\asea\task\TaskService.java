package com.asea.task;

import com.asea.audit.AuditEventType;
import com.asea.audit.AuditService;
import com.asea.budget.BudgetManager;
import com.asea.common.exceptions.EntityNotFoundException;
import com.asea.common.exceptions.InvalidTransitionException;
import com.asea.common.exceptions.PermissionDeniedException;
import com.asea.state.StateGraph;
import com.asea.state.StateTransition;
import com.asea.state.StateTransitionRepository;
import com.asea.state.TaskState;
import com.asea.task.dto.TaskCreateRequest;
import com.asea.task.dto.TaskHistoryResponse;
import com.asea.task.dto.TaskResponse;
import com.asea.task.dto.TaskTransitionRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Manages the lifecycle of {@link Task} entities.
 *
 * <p>All state transitions are validated through {@link StateGraph} and
 * recorded in {@link StateTransition} for full auditability.</p>
 *
 * <p>Every new task receives an initialised {@link com.asea.budget.Budget} record
 * at creation time. Budget is required by the architecture: operations must not
 * proceed when limits are exhausted.</p>
 *
 * <p><b>Tenant isolation:</b> All retrieval operations are scoped to the tenantId
 * extracted from the authenticated context. Callers cannot access tasks belonging
 * to other tenants. When a task is fetched by ID, its tenantId is verified against
 * the required tenant before returning data.</p>
 *
 * <p><b>Known gap (Stage 1):</b> With the current API-key authentication model,
 * the tenantId is still caller-supplied in the request body rather than derived
 * from an authenticated principal. This gap is documented and tracked for Stage 2
 * when JWT/OIDC authentication binds tenant from token claims.</p>
 */
@Service
public class TaskService {

    private static final Logger log = LoggerFactory.getLogger(TaskService.class);

    private final TaskRepository taskRepository;
    private final StateTransitionRepository stateTransitionRepository;
    private final AuditService auditService;
    private final BudgetManager budgetManager;

    public TaskService(TaskRepository taskRepository,
                       StateTransitionRepository stateTransitionRepository,
                       AuditService auditService,
                       BudgetManager budgetManager) {
        this.taskRepository = taskRepository;
        this.stateTransitionRepository = stateTransitionRepository;
        this.auditService = auditService;
        this.budgetManager = budgetManager;
    }

    /**
     * Creates a new task and initialises its budget record atomically.
     *
     * <p>Budget initialisation happens in the same transaction as task creation.
     * If budget initialisation fails, the task is not persisted.</p>
     */
    @Transactional
    public TaskResponse createTask(TaskCreateRequest request) {
        String taskId = "ASEA-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        Task task = new Task();
        task.setTenantId(request.tenantId());
        task.setTaskId(taskId);
        task.setRepositoryId(request.repositoryId());
        task.setTitle(request.title());
        task.setDescription(request.description());
        task.setIssueUrl(request.issueUrl());
        task.setTrigger(request.trigger());
        task.setTaskType(request.taskType());
        task.setPriority(request.priority() != null ? request.priority() : 0);
        task.setStatus(TaskState.CREATED);
        task.setCurrentState(TaskState.CREATED);
        task.setMaxAttempts(request.maxAttempts() != null ? request.maxAttempts() : 3);
        task.setBudgetTokens(request.budgetTokens());
        task.setBudgetCost(request.budgetCost());
        task.setMaxExecutionMs(request.maxExecutionMs());
        // Metadata must be valid JSON or null — validated at the service layer
        if (request.metadata() != null) {
            validateJsonString(request.metadata(), "metadata");
        }
        task.setMetadata(request.metadata());

        Task saved = taskRepository.save(task);

        // Architecture requirement: every task receives a persisted budget.
        // initializeBudget is called within this transaction so failure is atomic.
        budgetManager.initializeBudget(
                saved.getTenantId(),
                saved.getTaskId(),
                saved.getBudgetTokens(),
                saved.getBudgetCost(),
                saved.getMaxAttempts(),
                saved.getMaxExecutionMs());

        recordTransition(saved.getTaskId(), saved.getTenantId(), null, TaskState.CREATED,
                "TASK_CREATED", "Task created via API");
        auditService.record(saved.getTenantId(), AuditEventType.TASK_CREATED,
                "SYSTEM", saved.getTaskId(), null, TaskState.CREATED, null);

        log.info("Task created taskId={} tenantId={} type={}", taskId, task.getTenantId(), task.getTaskType());
        return toResponse(saved);
    }

    /**
     * Retrieves a task by its task ID, enforcing tenant ownership.
     *
     * @param taskId   the task's public identifier (e.g. "ASEA-1A2B3C4D")
     * @param tenantId the tenant that must own this task
     * @throws EntityNotFoundException  if the task does not exist
     * @throws PermissionDeniedException if the task belongs to a different tenant
     */
    @Transactional(readOnly = true)
    public TaskResponse getTask(String taskId, String tenantId) {
        Task task = taskRepository.findByTaskId(taskId)
                .orElseThrow(() -> new EntityNotFoundException("Task not found: " + taskId));
        // Tenant isolation: verify the task belongs to the requesting tenant
        if (!task.getTenantId().equals(tenantId)) {
            // Do not reveal that the task exists for a different tenant
            log.warn("Cross-tenant access attempt denied: taskId={} requestingTenant={} owningTenant={}",
                    taskId, tenantId, task.getTenantId());
            throw new EntityNotFoundException("Task not found: " + taskId);
        }
        return toResponse(task);
    }

    /**
     * Lists tasks for the specified tenant.
     *
     * <p>The tenantId is required — callers cannot list tasks across tenants.
     * A null tenantId is rejected to prevent accidental data leaks.</p>
     */
    @Transactional(readOnly = true)
    public Page<TaskResponse> listTasks(String tenantId, TaskState status, Pageable pageable) {
        if (tenantId == null || tenantId.isBlank()) {
            throw new com.asea.common.exceptions.ValidationException(
                    "tenantId is required for task listing");
        }
        Page<Task> page;
        if (status != null) {
            page = taskRepository.findByTenantIdAndStatus(tenantId, status, pageable);
        } else {
            page = taskRepository.findByTenantId(tenantId, pageable);
        }
        return page.map(this::toResponse);
    }

    /**
     * Returns the full state-transition history for a task, verifying tenant ownership.
     */
    @Transactional(readOnly = true)
    public List<TaskHistoryResponse> getTaskHistory(String taskId, String tenantId) {
        // Verify task exists and belongs to tenantId (reuse tenant-guarded getTask logic)
        Task task = taskRepository.findByTaskId(taskId)
                .orElseThrow(() -> new EntityNotFoundException("Task not found: " + taskId));
        if (!task.getTenantId().equals(tenantId)) {
            log.warn("Cross-tenant history access denied: taskId={} requestingTenant={}", taskId, tenantId);
            throw new EntityNotFoundException("Task not found: " + taskId);
        }
        return stateTransitionRepository.findByTaskId(taskId).stream()
                .map(st -> new TaskHistoryResponse(
                        st.getId(), st.getTaskId(), st.getFromState(), st.getToState(),
                        st.getTrigger(), st.getReason(), st.getCreatedAt()))
                .collect(Collectors.toList());
    }

    /**
     * Performs a validated state transition.
     *
     * <p>Enforces:</p>
     * <ul>
     *   <li>Task belongs to the requesting tenant</li>
     *   <li>Task is not in a terminal state</li>
     *   <li>The requested transition is legal per the state graph</li>
     * </ul>
     *
     * <p>Uses optimistic locking via {@code @Version} on {@link Task} to prevent
     * concurrent requests from silently overwriting state.</p>
     */
    @Transactional
    public TaskResponse transitionTask(String taskId, String tenantId, TaskTransitionRequest request) {
        Task task = taskRepository.findByTaskId(taskId)
                .orElseThrow(() -> new EntityNotFoundException("Task not found: " + taskId));

        // Tenant isolation check
        if (!task.getTenantId().equals(tenantId)) {
            log.warn("Cross-tenant transition attempt denied: taskId={} requestingTenant={}", taskId, tenantId);
            throw new EntityNotFoundException("Task not found: " + taskId);
        }

        TaskState fromState = task.getCurrentState();
        if (fromState.isTerminal()) {
            throw new InvalidTransitionException("Task is already in terminal state: " + fromState);
        }
        StateGraph.validate(fromState, request.toState());

        task.setCurrentState(request.toState());
        task.setStatus(request.toState());
        if (request.toState() == TaskState.COMPLETED) {
            task.setCompletedAt(LocalDateTime.now());
        }
        // @Version field on Task provides optimistic locking — concurrent transition
        // requests will fail with OptimisticLockException rather than silently winning
        Task saved = taskRepository.save(task);

        recordTransition(taskId, task.getTenantId(), fromState, request.toState(),
                request.trigger(), request.reason());
        auditService.record(task.getTenantId(), AuditEventType.STATE_CHANGED,
                "SYSTEM", taskId, fromState, request.toState(), null);

        log.info("Task transitioned taskId={} from={} to={}", taskId, fromState, request.toState());
        return toResponse(saved);
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    private void recordTransition(String taskId, String tenantId, TaskState from, TaskState to,
                                  String trigger, String reason) {
        StateTransition st = new StateTransition();
        st.setTaskId(taskId);
        st.setTenantId(tenantId);
        st.setFromState(from);
        st.setToState(to);
        st.setTrigger(trigger);
        st.setReason(reason);
        st.setCreatedAt(LocalDateTime.now());
        stateTransitionRepository.save(st);
    }

    /**
     * Validates that a string is valid JSON — rejects unsafe/malformed values
     * before they are stored in a JSONB column.
     *
     * @throws com.asea.common.exceptions.ValidationException if not valid JSON
     */
    private void validateJsonString(String json, String fieldName) {
        if (json == null) return;
        try {
            com.fasterxml.jackson.databind.ObjectMapper mapper =
                    new com.fasterxml.jackson.databind.ObjectMapper();
            mapper.readTree(json);
        } catch (Exception e) {
            throw new com.asea.common.exceptions.ValidationException(
                    fieldName + " must be valid JSON: " + e.getMessage());
        }
    }

    private TaskResponse toResponse(Task task) {
        return new TaskResponse(
                task.getId(), task.getTaskId(), task.getTenantId(), task.getRepositoryId(),
                task.getTitle(), task.getDescription(), task.getIssueUrl(), task.getTrigger(),
                task.getTaskType(), task.getPriority(), task.getStatus(), task.getCurrentState(),
                task.getAssignedAgent(), task.getBudgetTokens(), task.getBudgetCost(),
                task.getMaxAttempts(), task.getMaxExecutionMs(),
                task.getCreatedAt(), task.getUpdatedAt(), task.getCompletedAt(), task.getMetadata());
    }
}
