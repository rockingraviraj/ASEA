package com.asea.task;

import com.asea.state.TaskState;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TaskRepository extends JpaRepository<Task, Long> {

    Optional<Task> findByTaskId(String taskId);

    Page<Task> findByTenantId(String tenantId, Pageable pageable);

    Page<Task> findByTenantIdAndStatus(String tenantId, TaskState status, Pageable pageable);

    List<Task> findByTenantIdAndCurrentState(String tenantId, TaskState currentState);

    long countByTenantIdAndStatus(String tenantId, TaskState status);

    @Query("SELECT COUNT(t) FROM Task t WHERE t.tenantId = :tenantId")
    long countByTenantId(@Param("tenantId") String tenantId);

    @Query("SELECT t FROM Task t WHERE t.tenantId = :tenantId " +
           "AND (t.title LIKE %:q% OR t.taskId LIKE %:q% OR t.description LIKE %:q%)")
    List<Task> search(@Param("tenantId") String tenantId, @Param("q") String q);
}