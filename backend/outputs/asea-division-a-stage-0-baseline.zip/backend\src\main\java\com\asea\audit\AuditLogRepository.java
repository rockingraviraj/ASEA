package com.asea.audit;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AuditLogRepository extends JpaRepository<AuditLog, Long> {

    List<AuditLog> findByTaskIdOrderByCreatedAtAsc(String taskId);

    Page<AuditLog> findByTenantIdOrderByCreatedAtDesc(String tenantId, Pageable pageable);

    @Query("SELECT a FROM AuditLog a WHERE a.tenantId = :tenantId AND a.eventType = :eventType " +
           "ORDER BY a.createdAt DESC")
    List<AuditLog> findByTenantIdAndEventType(@Param("tenantId") String tenantId,
                                              @Param("eventType") AuditEventType eventType);

    long countByTaskId(String taskId);
}
