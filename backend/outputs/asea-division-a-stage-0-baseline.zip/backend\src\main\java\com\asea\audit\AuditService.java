package com.asea.audit;

import com.asea.state.TaskState;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Central audit recording service.
 *
 * <p>Runs in {@link Propagation#REQUIRES_NEW} so that an audit record is
 * always committed even if the outer transaction rolls back. This ensures
 * audit completeness including failure events.</p>
 */
@Service
public class AuditService {

    private static final Logger log = LoggerFactory.getLogger(AuditService.class);

    private final AuditLogRepository auditLogRepository;

    public AuditService(AuditLogRepository auditLogRepository) {
        this.auditLogRepository = auditLogRepository;
    }

    /**
     * Records an audit event. Runs in its own transaction to guarantee persistence.
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public AuditLog record(String tenantId,
                           AuditEventType eventType,
                           String actor,
                           String taskId,
                           TaskState previousState,
                           TaskState newState,
                           String metadata) {
        AuditLog auditLog = new AuditLog();
        auditLog.setTenantId(tenantId);
        auditLog.setEventType(eventType);
        auditLog.setActor(actor != null ? actor : "SYSTEM");
        auditLog.setTaskId(taskId);
        auditLog.setPreviousState(previousState);
        auditLog.setNewState(newState);
        auditLog.setMetadata(metadata);
        auditLog.setCreatedAt(LocalDateTime.now());

        AuditLog saved = auditLogRepository.save(auditLog);
        log.debug("Audit recorded eventType={} taskId={} actor={} tenantId={}",
                eventType, taskId, actor, tenantId);
        return saved;
    }

    /**
     * Convenience overload for events not associated with a specific task.
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public AuditLog record(String tenantId, AuditEventType eventType, String actor, String metadata) {
        return record(tenantId, eventType, actor, null, null, null, metadata);
    }

    @Transactional(readOnly = true)
    public List<AuditLog> getAuditLogsForTask(String taskId) {
        return auditLogRepository.findByTaskIdOrderByCreatedAtAsc(taskId);
    }
}
