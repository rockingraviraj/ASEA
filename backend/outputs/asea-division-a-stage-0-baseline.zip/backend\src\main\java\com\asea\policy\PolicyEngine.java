package com.asea.policy;

import com.asea.audit.AuditEventType;
import com.asea.audit.AuditService;
import com.asea.common.exceptions.PolicyViolationException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Policy Engine — answers "Is this action allowed by policy?"
 *
 * <p>Separate from the Permission Manager which answers "Is this actor allowed to do it?"
 * Policy rules are tenant-scoped and stored in PostgreSQL.</p>
 *
 * <p>Risk is always evidence-based. The engine considers:
 * <ul>
 *   <li>Explicit policy rules in the database</li>
 *   <li>File path sensitivity heuristics</li>
 *   <li>Modification size</li>
 *   <li>Security-relevant operations</li>
 * </ul>
 * </p>
 *
 * <p>All audit metadata is constructed with Jackson ObjectMapper to guarantee
 * valid JSON output even when factor strings contain special characters.</p>
 */
@Service
public class PolicyEngine {

    private static final Logger log = LoggerFactory.getLogger(PolicyEngine.class);

    // Paths that always require human approval regardless of policy
    private static final List<String> ALWAYS_CRITICAL_PATHS = List.of(
            "infrastructure/", ".github/workflows/", "Dockerfile", "docker-compose",
            "security/", "auth/", "payment/", "secrets", ".env"
    );

    private static final List<String> HIGH_RISK_PATHS = List.of(
            "src/main/", "src/test/", "pom.xml", "build.gradle",
            "application.properties", "application.yml"
    );

    private final PolicyRepository policyRepository;
    private final AuditService auditService;
    private final ObjectMapper objectMapper;

    public PolicyEngine(PolicyRepository policyRepository,
                        AuditService auditService,
                        ObjectMapper objectMapper) {
        this.policyRepository = policyRepository;
        this.auditService = auditService;
        this.objectMapper = objectMapper;
    }

    /**
     * Evaluates whether an action is permitted for the given tenant.
     * Always audits the decision.
     *
     * @param tenantId     the tenant requesting the action
     * @param action       the action being evaluated (e.g. "WRITE_SOURCE", "CREATE_PR")
     * @param taskId       task context for audit logging
     * @param filePaths    file paths affected by the operation (may be empty)
     * @param modifications number of lines/files being modified
     * @return PolicyDecision with risk assessment and contributing factors
     */
    @Transactional(readOnly = true)
    public PolicyDecision evaluate(String tenantId, String action, String taskId,
                                   List<String> filePaths, int modifications) {
        List<String> factors = new ArrayList<>();
        RiskLevel riskLevel = RiskLevel.LOW;
        boolean requiresApproval = false;

        // 1. Check explicit database policy
        Optional<Policy> explicitPolicy = policyRepository.findByTenantIdAndAction(tenantId, action);
        if (explicitPolicy.isPresent()) {
            Policy policy = explicitPolicy.get();
            if (!policy.isAllowed()) {
                factors.add("Explicit policy DENY for action: " + action);
                PolicyDecision decision = PolicyDecision.deny(policy.getRiskLevel(), factors,
                        "Action blocked by policy: " + policy.getName());
                auditDecision(tenantId, taskId, action, decision, AuditEventType.POLICY_DENIED);
                log.warn("Policy DENIED tenantId={} action={} taskId={} policy={}",
                        tenantId, action, taskId, policy.getName());
                return decision;
            }
            riskLevel = policy.getRiskLevel();
            factors.add("Explicit policy found: " + policy.getName() + " risk=" + riskLevel);
            if (policy.isRequiresApproval()) {
                requiresApproval = true;
                factors.add("Policy requires human approval");
            }
            if (policy.getMaxModifications() != null && modifications > policy.getMaxModifications()) {
                factors.add("Modification count " + modifications + " exceeds policy max " + policy.getMaxModifications());
                requiresApproval = true;
                riskLevel = escalateRisk(riskLevel);
            }
        }

        // 2. File path sensitivity analysis
        for (String path : filePaths) {
            for (String criticalPath : ALWAYS_CRITICAL_PATHS) {
                if (path.contains(criticalPath)) {
                    factors.add("Critical path touched: " + path);
                    riskLevel = RiskLevel.CRITICAL;
                    requiresApproval = true;
                }
            }
            if (riskLevel != RiskLevel.CRITICAL) {
                for (String highRiskPath : HIGH_RISK_PATHS) {
                    if (path.contains(highRiskPath) && riskLevel.ordinal() < RiskLevel.HIGH.ordinal()) {
                        factors.add("High-risk path touched: " + path);
                        riskLevel = RiskLevel.HIGH;
                    }
                }
            }
        }

        // 3. Modification volume
        if (modifications > 500) {
            factors.add("Large modification: " + modifications + " lines");
            if (riskLevel.ordinal() < RiskLevel.HIGH.ordinal()) {
                riskLevel = RiskLevel.HIGH;
                requiresApproval = true;
            }
        } else if (modifications > 100) {
            factors.add("Medium modification: " + modifications + " lines");
            if (riskLevel.ordinal() < RiskLevel.MEDIUM.ordinal()) {
                riskLevel = RiskLevel.MEDIUM;
            }
        }

        PolicyDecision decision = requiresApproval
                ? PolicyDecision.allowWithApproval(riskLevel, factors, "Human approval required for risk level: " + riskLevel)
                : PolicyDecision.allow(riskLevel, factors);

        AuditEventType auditEvent = requiresApproval
                ? AuditEventType.POLICY_APPROVAL_REQUIRED
                : AuditEventType.POLICY_ALLOWED;
        auditDecision(tenantId, taskId, action, decision, auditEvent);

        log.info("Policy ALLOWED tenantId={} action={} taskId={} riskLevel={} requiresApproval={}",
                tenantId, action, taskId, riskLevel, requiresApproval);
        return decision;
    }

    /**
     * Enforces policy — throws {@link PolicyViolationException} if denied.
     */
    public void enforce(String tenantId, String action, String taskId,
                        List<String> filePaths, int modifications) {
        PolicyDecision decision = evaluate(tenantId, action, taskId, filePaths, modifications);
        if (!decision.allowed()) {
            throw new PolicyViolationException("Policy violation for action: " + action
                    + ". Reason: " + decision.reason());
        }
    }

    // -------------------------------------------------------------------------

    private RiskLevel escalateRisk(RiskLevel current) {
        return switch (current) {
            case LOW -> RiskLevel.MEDIUM;
            case MEDIUM -> RiskLevel.HIGH;
            case HIGH, CRITICAL -> RiskLevel.CRITICAL;
        };
    }

    /**
     * Builds audit metadata using Jackson ObjectMapper to guarantee valid JSON.
     * Replaces the previous String.format() approach that produced invalid JSON
     * when factor strings contained quotes or special characters.
     */
    private void auditDecision(String tenantId, String taskId, String action,
                                PolicyDecision decision, AuditEventType eventType) {
        String metadata;
        try {
            ObjectNode node = objectMapper.createObjectNode();
            node.put("action", action);
            node.put("riskLevel", decision.riskLevel() != null ? decision.riskLevel().name() : null);
            node.put("allowed", decision.allowed());
            node.put("requiresApproval", decision.requiresApproval());
            ArrayNode factorsNode = node.putArray("factors");
            for (String factor : decision.contributingFactors()) {
                factorsNode.add(factor);
            }
            metadata = objectMapper.writeValueAsString(node);
        } catch (Exception e) {
            // Fallback — never let audit serialisation failure break the main flow
            log.error("Failed to serialize policy audit metadata: {}", e.getMessage(), e);
            metadata = "{\"error\":\"serialization_failed\"}";
        }
        auditService.record(tenantId, eventType, "POLICY_ENGINE", taskId, null, null, metadata);
    }
}
