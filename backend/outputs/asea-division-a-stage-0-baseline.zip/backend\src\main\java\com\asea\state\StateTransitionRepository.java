package com.asea.state;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StateTransitionRepository extends JpaRepository<StateTransition, Long> {

    List<StateTransition> findByTaskIdOrderByCreatedAtAsc(String taskId);

    List<StateTransition> findByTaskId(String taskId);

    @Query("SELECT COUNT(st) FROM StateTransition st WHERE st.taskId = :taskId AND st.toState = :state")
    long countByTaskIdAndToState(@Param("taskId") String taskId, @Param("state") TaskState state);

    @Query("SELECT COUNT(st) FROM StateTransition st WHERE st.taskId = :taskId AND st.toState = 'RECOVERING'")
    long countRecoveryAttempts(@Param("taskId") String taskId);
}