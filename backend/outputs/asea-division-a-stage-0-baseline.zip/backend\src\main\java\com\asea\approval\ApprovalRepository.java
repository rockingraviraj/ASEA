package com.asea.approval;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ApprovalRepository extends JpaRepository<Approval, Long> {

    Optional<Approval> findByApprovalId(String approvalId);

    Optional<Approval> findByTenantIdAndTaskIdAndApprovalId(String tenantId, String taskId, String approvalId);

    List<Approval> findByTenantIdAndTaskId(String tenantId, String taskId);

    Optional<Approval> findTopByTenantIdAndTaskIdAndStatusOrderByRequestedAtDesc(
            String tenantId, String taskId, String status);

    Optional<Approval> findTopByTenantIdAndTaskIdAndEscalationTypeAndStatusOrderByRequestedAtDesc(
            String tenantId, String taskId, String escalationType, String status);
}
