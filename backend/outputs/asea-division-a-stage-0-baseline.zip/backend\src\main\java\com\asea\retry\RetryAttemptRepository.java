package com.asea.retry;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RetryAttemptRepository extends JpaRepository<RetryAttempt, Long> {

    List<RetryAttempt> findByTaskIdOrderByAttemptNumberAsc(String taskId);

    long countByTaskId(String taskId);

    @Query("SELECT MAX(r.attemptNumber) FROM RetryAttempt r WHERE r.taskId = :taskId")
    Integer findMaxAttemptNumber(@Param("taskId") String taskId);

    @Query("SELECT r FROM RetryAttempt r WHERE r.taskId = :taskId AND r.status = 'PENDING'")
    List<RetryAttempt> findPendingAttempts(@Param("taskId") String taskId);
}
