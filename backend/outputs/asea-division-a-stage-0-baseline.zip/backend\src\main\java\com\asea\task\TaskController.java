package com.asea.task;

import com.asea.common.ApiResponse;
import com.asea.state.TaskState;
import com.asea.task.dto.TaskCreateRequest;
import com.asea.task.dto.TaskHistoryResponse;
import com.asea.task.dto.TaskResponse;
import com.asea.task.dto.TaskTransitionRequest;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * REST controller for ASEA task management.
 *
 * <p>Exposes CRUD and lifecycle operations for tasks.
 * All business logic lives in {@link TaskService}; this class is a thin HTTP adapter.</p>
 *
 * <p><b>Tenant isolation:</b> The {@code tenantId} parameter is required on all
 * retrieval operations. Until JWT authentication is implemented (Stage 2), the
 * tenantId is verified against the stored task tenant to prevent cross-tenant access.
 * No response reveals the existence of tasks belonging to other tenants.</p>
 */
@Validated
@RestController
@RequestMapping("/api/v1/tasks")
@Tag(name = "Tasks", description = "ASEA task management endpoints")
public class TaskController {

    private final TaskService taskService;

    public TaskController(TaskService taskService) {
        this.taskService = taskService;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(summary = "Create a new task", description = "Submits a new engineering task to ASEA. A budget record is created atomically with the task.")
    public ApiResponse<TaskResponse> createTask(@Valid @RequestBody TaskCreateRequest request) {
        return ApiResponse.ok(taskService.createTask(request));
    }

    @GetMapping("/{taskId}")
    @Operation(summary = "Get task by ID", description = "Returns a task. The tenantId must match the task's owner — other tenants receive 404.")
    public ApiResponse<TaskResponse> getTask(
            @Parameter(description = "Task ID (e.g. ASEA-1A2B3C4D)") @PathVariable String taskId,
            @Parameter(description = "Tenant ID that owns the task", required = true)
            @RequestParam @NotBlank @Size(max = 50) String tenantId) {
        return ApiResponse.ok(taskService.getTask(taskId, tenantId));
    }

    @GetMapping
    @Operation(summary = "List tasks", description = "Returns paginated tasks for the specified tenant. tenantId is required.")
    public ApiResponse<Page<TaskResponse>> listTasks(
            @Parameter(description = "Tenant ID (required)", required = true)
            @RequestParam @NotBlank @Size(max = 50) String tenantId,
            @Parameter(description = "Optional status filter")
            @RequestParam(required = false) TaskState status,
            @PageableDefault(size = 20, sort = "createdAt") Pageable pageable) {
        return ApiResponse.ok(taskService.listTasks(tenantId, status, pageable));
    }

    @GetMapping("/{taskId}/history")
    @Operation(summary = "Get task state history", description = "Returns the full state-transition history for a task.")
    public ApiResponse<List<TaskHistoryResponse>> getTaskHistory(
            @PathVariable String taskId,
            @Parameter(description = "Tenant ID that owns the task", required = true)
            @RequestParam @NotBlank @Size(max = 50) String tenantId) {
        return ApiResponse.ok(taskService.getTaskHistory(taskId, tenantId));
    }

    @PutMapping("/{taskId}/transition")
    @Operation(summary = "Transition task state",
               description = "Requests a validated state transition for a task. The tenantId must match the task owner.")
    public ApiResponse<TaskResponse> transitionTask(
            @PathVariable String taskId,
            @Parameter(description = "Tenant ID that owns the task", required = true)
            @RequestParam @NotBlank @Size(max = 50) String tenantId,
            @Valid @RequestBody TaskTransitionRequest request) {
        return ApiResponse.ok(taskService.transitionTask(taskId, tenantId, request));
    }
}
