package com.asea.budget;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import jakarta.persistence.LockModeType;
import java.util.Optional;

@Repository
public interface BudgetRepository extends JpaRepository<Budget, Long> {

    Optional<Budget> findByTaskId(String taskId);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT b FROM Budget b WHERE b.taskId = :taskId")
    Optional<Budget> findByTaskIdForUpdate(@Param("taskId") String taskId);

    Optional<Budget> findByTenantIdAndTaskId(String tenantId, String taskId);

    long countByTenantIdAndStatus(String tenantId, String status);
}
