package com.asea.security;

import com.asea.common.exceptions.PermissionDeniedException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

/**
 * Resolves the authenticated tenant identity server-side.
 *
 * <p>Never trusts client-supplied tenant identifiers as proof of ownership.
 * Extracts verified tenant context from the authenticated principal or server-configured
 * MVP single-tenant boundary.</p>
 */
@Component
public class TenantResolver {

    private final String defaultTenantId;

    public TenantResolver(@Value("${asea.security.tenant-id:default-tenant}") String defaultTenantId) {
        this.defaultTenantId = defaultTenantId;
    }

    /**
     * Resolves the verified tenant ID for the current authenticated context.
     *
     * @return the verified tenant ID
     * @throws PermissionDeniedException if no authenticated context is present
     */
    public String resolveRequiredTenantId() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated()) {
            throw new PermissionDeniedException("Unauthenticated request: no verified tenant context");
        }
        if (auth.getPrincipal() instanceof AseaPrincipal principal) {
            return principal.tenantId();
        }
        return defaultTenantId;
    }

    /**
     * Validates that an operation targeting a specific tenant matches the authenticated tenant context.
     *
     * @param requestedTenantId the tenant ID specified in a request (optional)
     * @return the verified server-side tenant ID
     */
    public String validateAndResolveTenant(String requestedTenantId) {
        String verifiedTenant = resolveRequiredTenantId();
        if (requestedTenantId != null && !requestedTenantId.isBlank() && !requestedTenantId.equals(verifiedTenant)) {
            throw new PermissionDeniedException("Cross-tenant access denied: requested tenant does not match authenticated identity");
        }
        return verifiedTenant;
    }

    public String getDefaultTenantId() {
        return defaultTenantId;
    }
}
