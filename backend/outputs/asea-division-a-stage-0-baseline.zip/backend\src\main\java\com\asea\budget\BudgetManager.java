package com.asea.budget;

import com.asea.audit.AuditEventType;
import com.asea.audit.AuditService;
import com.asea.common.exceptions.BudgetExceededException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Budget Manager — enforces spending limits for tasks.
 *
 * <p>Before any expensive operation (LLM call, sandbox execution), the orchestrator
 * checks the budget. When a limit is exceeded, the task is escalated rather than
 * allowed to continue indefinitely.</p>
 *
 * <p>Uses pessimistic locking to prevent race conditions when multiple concurrent
 * operations consume budget simultaneously.</p>
 *
 * <p>No infinite loops: when budget is exhausted, execution stops and the task
 * transitions to ESCALATED.</p>
 */
@Service
public class BudgetManager {

    private static final Logger log = LoggerFactory.getLogger(BudgetManager.class);

    private final BudgetRepository budgetRepository;
    private final AuditService auditService;
    private final ObjectMapper objectMapper;

    public BudgetManager(BudgetRepository budgetRepository,
                         AuditService auditService,
                         ObjectMapper objectMapper) {
        this.budgetRepository = budgetRepository;
        this.auditService = auditService;
        this.objectMapper = objectMapper;
    }

    /**
     * Initialises a budget record when a task is created.
     */
    @Transactional
    public Budget initializeBudget(String tenantId, String taskId,
                                   Long maxTokens, BigDecimal maxCost,
                                   Integer maxAttempts, Long maxExecutionMs) {
        Budget budget = new Budget();
        budget.setTenantId(tenantId);
        budget.setTaskId(taskId);
        budget.setMaxTokens(maxTokens);
        budget.setMaxCost(maxCost);
        budget.setMaxAttempts(maxAttempts != null ? maxAttempts : 3);
        budget.setMaxExecutionMs(maxExecutionMs);
        budget.setUsedTokens(0L);
        budget.setUsedCost(BigDecimal.ZERO);
        budget.setCurrentAttempts(0);
        budget.setStartedAt(LocalDateTime.now());
        budget.setStatus("ACTIVE");
        budget.setCreatedAt(LocalDateTime.now());
        budget.setUpdatedAt(LocalDateTime.now());

        Budget saved = budgetRepository.save(budget);
        log.info("Budget initialized taskId={} maxTokens={} maxCost={} maxAttempts={}",
                taskId, maxTokens, maxCost, maxAttempts);
        return saved;
    }

    /**
     * Checks whether the task has sufficient budget to proceed.
     * Does NOT consume budget — call {@link #consume} after the operation completes.
     */
    @Transactional(readOnly = true)
    public BudgetCheckResult check(String taskId) {
        Budget budget = budgetRepository.findByTaskId(taskId).orElse(null);
        if (budget == null) {
            // No budget configured — allow by default
            return BudgetCheckResult.allow(null, null, null);
        }

        if (budget.isTokenBudgetExhausted()) {
            log.warn("Budget token limit exhausted taskId={} used={} max={}",
                    taskId, budget.getUsedTokens(), budget.getMaxTokens());
            auditBudget(budget, "TOKEN_LIMIT_EXCEEDED");
            return BudgetCheckResult.deny("Token limit exceeded: used="
                    + budget.getUsedTokens() + " max=" + budget.getMaxTokens());
        }
        if (budget.isCostBudgetExhausted()) {
            log.warn("Budget cost limit exhausted taskId={} used={} max={}",
                    taskId, budget.getUsedCost(), budget.getMaxCost());
            auditBudget(budget, "COST_LIMIT_EXCEEDED");
            return BudgetCheckResult.deny("Cost limit exceeded: used="
                    + budget.getUsedCost() + " max=" + budget.getMaxCost());
        }
        if (budget.isAttemptBudgetExhausted()) {
            log.warn("Budget attempt limit exhausted taskId={} used={} max={}",
                    taskId, budget.getCurrentAttempts(), budget.getMaxAttempts());
            auditBudget(budget, "ATTEMPT_LIMIT_EXCEEDED");
            return BudgetCheckResult.deny("Attempt limit exceeded: used="
                    + budget.getCurrentAttempts() + " max=" + budget.getMaxAttempts());
        }

        Integer remaining = budget.getMaxAttempts() != null
                ? budget.getMaxAttempts() - budget.getCurrentAttempts() : null;
        return BudgetCheckResult.allow(budget.remainingTokens(), null, remaining);
    }

    /**
     * Enforces budget — throws {@link BudgetExceededException} if exhausted.
     */
    public void enforce(String taskId) {
        BudgetCheckResult result = check(taskId);
        if (!result.allowed()) {
            throw new BudgetExceededException("Budget exhausted for task " + taskId
                    + ": " + result.exhaustedReason());
        }
    }

    /**
     * Records consumption of tokens and cost after an LLM call.
     * Uses pessimistic lock to prevent concurrent update corruption.
     */
    @Transactional
    public void consume(String taskId, long tokensUsed, BigDecimal costIncurred) {
        Budget budget = budgetRepository.findByTaskIdForUpdate(taskId).orElse(null);
        if (budget == null) return;

        budget.setUsedTokens((budget.getUsedTokens() != null ? budget.getUsedTokens() : 0L) + tokensUsed);
        BigDecimal current = budget.getUsedCost() != null ? budget.getUsedCost() : BigDecimal.ZERO;
        budget.setUsedCost(current.add(costIncurred != null ? costIncurred : BigDecimal.ZERO));
        budget.setUpdatedAt(LocalDateTime.now());
        budgetRepository.save(budget);

        log.debug("Budget consumed taskId={} tokens={} cost={} totalTokens={} totalCost={}",
                taskId, tokensUsed, costIncurred, budget.getUsedTokens(), budget.getUsedCost());
        auditBudget(budget, "CONSUMED");
    }

    /**
     * Increments the attempt counter. Call when starting a new attempt/retry.
     */
    @Transactional
    public void incrementAttempts(String taskId) {
        Budget budget = budgetRepository.findByTaskIdForUpdate(taskId).orElse(null);
        if (budget == null) return;

        int newAttempts = (budget.getCurrentAttempts() != null ? budget.getCurrentAttempts() : 0) + 1;
        budget.setCurrentAttempts(newAttempts);
        budget.setUpdatedAt(LocalDateTime.now());
        budgetRepository.save(budget);

        log.info("Budget attempt incremented taskId={} currentAttempts={} maxAttempts={}",
                taskId, newAttempts, budget.getMaxAttempts());
    }

    // -------------------------------------------------------------------------

    /**
     * Builds audit metadata using Jackson ObjectMapper to guarantee valid JSON.
     * Avoids NPE from null usedTokens and handles special characters in strings safely.
     */
    private void auditBudget(Budget budget, String event) {
        String metadata;
        try {
            ObjectNode node = objectMapper.createObjectNode();
            node.put("event", event);
            node.put("usedTokens", budget.getUsedTokens() != null ? budget.getUsedTokens() : 0L);
            node.put("usedCost",
                    budget.getUsedCost() != null ? budget.getUsedCost().toPlainString() : "0");
            node.put("currentAttempts",
                    budget.getCurrentAttempts() != null ? budget.getCurrentAttempts() : 0);
            metadata = objectMapper.writeValueAsString(node);
        } catch (Exception e) {
            log.error("Failed to serialize budget audit metadata: {}", e.getMessage(), e);
            metadata = "{\"error\":\"serialization_failed\"}";
        }
        auditService.record(budget.getTenantId(), AuditEventType.BUDGET_CHECKED,
                "BUDGET_MANAGER", budget.getTaskId(), null, null, metadata);
    }
}
