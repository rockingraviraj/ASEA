package com.asea.task.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;

public record TaskCreateRequest(
        @Size(max = 50, message = "tenantId must be at most 50 characters")
        String tenantId,

        Long repositoryId,

        @Size(max = 500, message = "issueUrl must be at most 500 characters")
        String issueUrl,

        @NotBlank(message = "title is required")
        @Size(max = 500, message = "title must be at most 500 characters")
        String title,

        String description,

        String trigger,

        @NotBlank(message = "taskType is required")
        @Size(max = 50, message = "taskType must be at most 50 characters")
        String taskType,

        @Min(value = 0, message = "priority must be >= 0")
        Integer priority,

        @Min(value = 1, message = "budgetTokens must be >= 1")
        Long budgetTokens,

        @DecimalMin(value = "0.0", inclusive = false, message = "budgetCost must be positive")
        BigDecimal budgetCost,

        @Min(value = 1, message = "maxAttempts must be >= 1")
        @Max(value = 10, message = "maxAttempts must be <= 10")
        Integer maxAttempts,

        @Min(value = 1000, message = "maxExecutionMs must be at least 1000ms")
        Long maxExecutionMs,

        String metadata) {
}